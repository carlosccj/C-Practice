import java.util.Random;

public class EquipoLimpieza extends Thread {

    Aseo aseo; //recurso compartido
    Random r; //tiempo random que  la persona del serv. de limpieza está en el baño

    public EquipoLimpieza (Aseo aseo) {
        this.aseo = aseo;
        r = new Random();
    }

    @Override
    public void run() {
        while (!isInterrupted()) {
            try {
                Thread.sleep(r.nextInt(5000)); //tiempo que espera el personal de limpieza en volver a limpiar
                aseo.entraPersonaLimpieza();
                Thread.sleep(r.nextInt(5000)); //tiempo en limpiar el aseo
                aseo.salePersonaLimpieza();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            
        }
    }
}
