/**
 * CentroComercial
 */
public class CentroComercial {
    public static void main(String[] args) {
        
        final int N_CLIENTES = 10;

        Aseo aseo = new Aseo(N_CLIENTES); // aseo del cc
      
        Cliente clientes[] = new Cliente[N_CLIENTES]; //clientes en el cc
        // personal de limpieza en el cc
        EquipoLimpieza empleado = new EquipoLimpieza(aseo);
        for (int i=0; i<N_CLIENTES;i++){
            clientes[i] = new Cliente(i, aseo);
        }
        for (int i=0; i<N_CLIENTES;i++){
            clientes[i].start();
        }
        empleado.start();
    }
}