import java.util.Random;

public class Cliente extends Thread {

    int id; // id cliente
    Aseo aseo; //recurso compartido
    Random r; //tiempo random que el cliente está en el baño

    public Cliente (int id, Aseo aseo) {
        this.id = id;
        this.aseo = aseo;
        r = new Random();
    }

    @Override
    public void run() {
        while (!isInterrupted()) {
            try {
                aseo.entraCliente(id);
                Thread.sleep(r.nextInt(5000)); //tiempo en el aseo
                aseo.saleCliente(id);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }  
        }
    }

}
