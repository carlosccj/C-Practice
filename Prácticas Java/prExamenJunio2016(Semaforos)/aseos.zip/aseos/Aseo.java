import java.util.concurrent.Semaphore;

public class Aseo {

    private int clientesDentro;
    Semaphore[] puedeEntrarCliente ; // para controlar cuando puede entrar cada cliente
    Semaphore mutexClientes; //Exc. mutua de la var. clientesDentro para los clientes que entran al baño
    int numClientes; //clientes en el cc.
    Semaphore puedeEntrarLimpieza; //para controlar acceso al baño
    boolean personalLimpiezaQuiereEntrar; // quiere entrar el personal de limpieza?

    Aseo (int numClientes) {
        clientesDentro = 0;
        personalLimpiezaQuiereEntrar = true;
        this.numClientes = numClientes;
        puedeEntrarLimpieza = new Semaphore(1,true);//Inicialmente pueden entrar a limpiar el baño
        puedeEntrarCliente = new Semaphore [numClientes];
        //Inicialmente los clientes no pueden entrar hasta que se limpie el baño la primera vez
        for (int i=0;i<numClientes;i++){
            puedeEntrarCliente[i] = new Semaphore(0,true);
        }
        mutexClientes = new Semaphore(1,true);
    }

    public void entraCliente (int id) throws InterruptedException {
        System.out.println ("Cliente "+ id + "intenta entrar al baño");
        while (personalLimpiezaQuiereEntrar)
            puedeEntrarCliente[id].acquire();
        mutexClientes.acquire();
        System.out.println("Entra cliente "+  id);
        clientesDentro++;
        mutexClientes.release();
        
    }

    public void saleCliente (int id) throws InterruptedException {
        mutexClientes.acquire();
        System.out.println("Sale cliente "+  id);
        clientesDentro--;
        if (clientesDentro==0)//si no hay clientes, liberamos al servicio de limpieza por si quiere entrar
            puedeEntrarLimpieza.release();
        if (!personalLimpiezaQuiereEntrar) //cuando un cliente sale, podrá volver a entrar, si no quiere entrar el svcio de limpieza
            puedeEntrarCliente[id].release(); //el cliente puede volver a entrar
        mutexClientes.release();
    }

    public void entraPersonaLimpieza () throws InterruptedException {
        System.out.println("Personal de limpieza quiere entrar ...");
        personalLimpiezaQuiereEntrar = true;
        puedeEntrarLimpieza.acquire(); 
        System.out.println("Entra equipo de limpieza al aseo. Limpiando baños ... Clientes no pueden entrar!!"); 
    }

    public void salePersonaLimpieza() throws InterruptedException { 
        System.out.println("Limpieza finalizada!!");
        personalLimpiezaQuiereEntrar = false;
        for (int i=0;i<numClientes;i++){ //Liberamos a los clientes
            puedeEntrarCliente[i].release();
        }     
    }

}
